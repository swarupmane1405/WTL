package com.scm.restapi.operation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserRepository userrepo;
	
	@PostMapping("/add")
	public User add(@RequestBody User user) {
		return userrepo.save(user); 
	}
	
@GetMapping("/all")
public List<User>users(){
	return userrepo.findAll();
	
}

@GetMapping("user/{id}")
public Optional<User> user(@PathVariable(value="id") int id){
	return userrepo.findById(id);
	
}

}
